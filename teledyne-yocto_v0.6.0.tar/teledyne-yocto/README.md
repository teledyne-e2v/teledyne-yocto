# teledyne-yocto

Custom Yocto environment for Teledyne v0.6.0.
