# teledyne-yocto

Custom Yocto environment for Teledyne v0.5.1.
